const path = require("path");

console.log(path.resolve(__dirname, "src")); // باید مسیر کامل بده

console.log(require('./vue.config.js'));