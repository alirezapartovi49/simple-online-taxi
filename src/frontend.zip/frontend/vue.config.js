const path = require('path');
const { defineConfig } = require('@vue/cli-service');

module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    compress: false,
  },
  configureWebpack: {
    resolve: {
      alias: {
        '@': path.join(__dirname, '..', "src"),
      },
      extensions: ['.js', '.vue', '.json'],
    },
  },
});
